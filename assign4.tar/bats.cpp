/*
	Bats Class
*/
#include <iostream>
#include "bats.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Bats() : Event()
** Description: Default Bats constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Bats::Bats() : Event(){
  //  cout << "Default Bats constructor called" << endl;
    away = 0;

}

/*************************************************************************************************************************************
** Function: Bats(int Away) : Event(Away)
** Description: Alternate Bats constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Bats::Bats(int Away) : Event(Away){
  //  cout << "Alternate Bats constructor called" << endl;
    this->away = Away;
}

/*************************************************************************************************************************************
** Function: getoriginalr()
** Description: Accessor for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original row
*************************************************************************************************************************************/
int Bats::getoriginalr() {
    return originalr;
}

/*************************************************************************************************************************************
** Function: getoriginalc()
** Description: Accessor for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original column
*************************************************************************************************************************************/
int Bats::getoriginalc(){
    return originalc;
}

/*************************************************************************************************************************************
** Function: getrow()
** Description: Accessor for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current row
*************************************************************************************************************************************/
int Bats::getrow() {
    return row;
}

/*************************************************************************************************************************************
** Function: getcolumn()
** Description: Accessor for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current column
*************************************************************************************************************************************/
int Bats::getcolumn(){
    return column;
}

/*************************************************************************************************************************************
** Function: setrow()
** Description: Mutator for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current row
*************************************************************************************************************************************/
void Bats::setrow(int Row) {
    this->row = Row;
}

/*************************************************************************************************************************************
** Function: setcolumn()
** Description: Mutator for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current column
*************************************************************************************************************************************/
void Bats::setcolumn(int Column){
    this->column = Column;
}

/*************************************************************************************************************************************
** Function: setoriginalr()
** Description: Mutator for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original row
*************************************************************************************************************************************/
void Bats::setoriginalr(int Originalr) {
    this->originalr = Originalr;
}

/*************************************************************************************************************************************
** Function: setoriginalc()
** Description: Mutator for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original column
*************************************************************************************************************************************/
void Bats::setoriginalc(int Originalc){
    this->originalc = Originalc;
}

/*************************************************************************************************************************************
** Function: encounter()
** Description: Sends message for encounter
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Bats::encounter() {
    cout << "You have entered the Bats room and been carried to a new room!" << endl;
}

/*************************************************************************************************************************************
** Function: percept()
** Description: Sends message for nearby
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Bats::percept() {
    cout << "You hear wings flapping." << endl;
}