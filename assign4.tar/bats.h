/*
	Bats Class
*/
#ifndef BATS_H
#define BATS_H

#include <iostream>
#include "event.h"

using namespace std;

class Bats : public Event {
public:
	Bats();
   Bats(int);  //inherits age from animal
	int getrow();
	int getcolumn();
	int getoriginalr();
    int getoriginalc();
	void setrow(int);
	void setcolumn(int);
	void setoriginalr(int);
    void setoriginalc(int);
	void encounter();
	void percept();
	bool wake();

private:
    int away;
	int row;
	int column;
	int originalr;
	int originalc;
    
};
#endif
