/*
	Event Class
*/
#include <iostream>
#include "event.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Event(int)
** Description: Alternate Event constructor
** Parameters: int Away
** Pre-conditions: int
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Event::Event(int Away) {
	//cout << "Alternate Event constructor called" << endl;
    this->away = Away; //how far away the Adventurer is
    
}

/*************************************************************************************************************************************
** Function: Evemt()
** Description: Default Event constructor
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Event::Event() {
	//cout << "Default Event constructor called" << endl;
    away = 0;
    
}

/*************************************************************************************************************************************
** Function: ~Event()
** Description: Event destructor
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: destructs all variables
*************************************************************************************************************************************/
Event::~Event() {
   // cout << "Event Destructor" << endl;
}
