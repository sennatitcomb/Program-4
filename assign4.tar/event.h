/*
	Event Class
*/
#ifndef EVENT_H
#define EVENT_H

#include <iostream>
using namespace std;

class Event {
public:
	Event();
	Event(int);
    virtual ~Event();
    virtual int getrow() = 0;
    virtual int getcolumn() = 0;
    virtual int getoriginalr() = 0;
    virtual int getoriginalc() = 0;
    virtual void setrow(int) = 0;
    virtual void setcolumn(int) = 0;
    virtual void setoriginalr(int) = 0;
    virtual void setoriginalc(int) = 0;
    virtual void encounter() = 0;
    virtual void percept() = 0;

private:
    int away;

};
#endif