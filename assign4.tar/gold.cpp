/*
	Gold Class
*/
#include <iostream>
#include "gold.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Gold() : Event()
** Description: Default Gold constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Gold::Gold() : Event(){
  //  cout << "Default Gold constructor called" << endl;
    away = 0;
    row = 0;
    originalr = 0;
    originalc = 0;
    column = 0;

}

/*************************************************************************************************************************************
** Function: Gold(int Away) : Event(Away)
** Description: Alternate Gold constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Gold::Gold(int Away) : Event(Away){
  //  cout << "Alternate Gold constructor called" << endl;
    this->away = Away;
    row = 0;
    originalr = 0;
    originalc = 0;
    column = 0;
}

/*************************************************************************************************************************************
** Function: getoriginalr()
** Description: Accessor for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original row
*************************************************************************************************************************************/
int Gold::getoriginalr() {
    return originalr;
}

/*************************************************************************************************************************************
** Function: getoriginalc()
** Description: Accessor for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original column
*************************************************************************************************************************************/
int Gold::getoriginalc(){
    return originalc;
}

/*************************************************************************************************************************************
** Function: getrow()
** Description: Accessor for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current row
*************************************************************************************************************************************/
int Gold::getrow() {
    return row;
}

/*************************************************************************************************************************************
** Function: getcolumn()
** Description: Accessor for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current column
*************************************************************************************************************************************/
int Gold::getcolumn(){
    return column;
}

/*************************************************************************************************************************************
** Function: setrow()
** Description: Mutator for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current row
*************************************************************************************************************************************/
void Gold::setrow(int Row) {
    this->row = Row;
}

/*************************************************************************************************************************************
** Function: setcolumn()
** Description: Mutator for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current column
*************************************************************************************************************************************/
void Gold::setcolumn(int Column){
    this->column = Column;
}

/*************************************************************************************************************************************
** Function: setoriginalr()
** Description: Mutator for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original row
*************************************************************************************************************************************/
void Gold::setoriginalr(int Originalr) {
    this->originalr = Originalr;
}

/*************************************************************************************************************************************
** Function: setoriginalc()
** Description: Mutator for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original column
*************************************************************************************************************************************/
void Gold::setoriginalc(int Originalc){
    this->originalc = Originalc;
}


/*************************************************************************************************************************************
** Function: encounter()
** Description: Sends message for encounter
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Gold::encounter() {
    cout << "You have found and collected the gold!" << endl;
}

/*************************************************************************************************************************************
** Function: percept()
** Description: Sends message for nearby
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Gold::percept() {
    cout << "You see a glimmer nearby." << endl;
}