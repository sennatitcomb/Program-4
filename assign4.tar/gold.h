/*
	Gold Class
*/
#ifndef GOLD_H
#define GOLD_H

#include <iostream>
#include "event.h"

using namespace std;

class Gold : public Event {
public:
	Gold();
    Gold(int);  //inherits age from animal
	int getrow();
	int getcolumn();
	int getoriginalr();
    int getoriginalc();
	void setrow(int);
	void setcolumn(int);
	void setoriginalr(int);
    void setoriginalc(int);
	void encounter();
	void percept();
	bool wake();

private:
   int away;
	int row;
	int column;
    int originalr;
	int originalc;
    
};
#endif
