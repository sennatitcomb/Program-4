/*
	Pit Class
*/
#include <iostream>
#include "pit.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Pit() : Event()
** Description: Default Pit constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Pit::Pit() : Event(){
  //  cout << "Default Pit constructor called" << endl;
    away = 0;

}

/*************************************************************************************************************************************
** Function: Pit(int Away) : Event(Away)
** Description: Alternate Pit constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Pit::Pit(int Away) : Event(Away){
  //  cout << "Alternate Pit constructor called" << endl;
    this->away = Away;
}

/*************************************************************************************************************************************
** Function: getoriginalr()
** Description: Accessor for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original row
*************************************************************************************************************************************/
int Pit::getoriginalr() {
    return originalr;
}

/*************************************************************************************************************************************
** Function: getoriginalc()
** Description: Accessor for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original column
*************************************************************************************************************************************/
int Pit::getoriginalc(){
    return originalc;
}

/*************************************************************************************************************************************
** Function: getrow()
** Description: Accessor for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current row
*************************************************************************************************************************************/
int Pit::getrow() {
    return row;
}

/*************************************************************************************************************************************
** Function: getcolumn()
** Description: Accessor for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current column
*************************************************************************************************************************************/
int Pit::getcolumn(){
    return column;
}

/*************************************************************************************************************************************
** Function: setrow()
** Description: Mutator for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current row
*************************************************************************************************************************************/
void Pit::setrow(int Row) {
    this->row = Row;
}

/*************************************************************************************************************************************
** Function: setcolumn()
** Description: Mutator for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current column
*************************************************************************************************************************************/
void Pit::setcolumn(int Column){
    this->column = Column;
}

/*************************************************************************************************************************************
** Function: setoriginalr()
** Description: Mutator for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original row
*************************************************************************************************************************************/
void Pit::setoriginalr(int Originalr) {
    this->originalr = Originalr;
}

/*************************************************************************************************************************************
** Function: setoriginalc()
** Description: Mutator for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original column
*************************************************************************************************************************************/
void Pit::setoriginalc(int Originalc){
    this->originalc = Originalc;
}

/*************************************************************************************************************************************
** Function: encounter()
** Description: Sends message for encounter
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Pit::encounter() {
    cout << "You have fallen into a pit and died!" << endl;
}

/*************************************************************************************************************************************
** Function: percept()
** Description: Sends message for nearby
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Pit::percept() {
    cout << "You feel a breeze." << endl;
}