/*
	Pit Class
*/
#ifndef PIT_H
#define PIT_H

#include <iostream>
#include "event.h"

using namespace std;

class Pit : public Event {
public:
	Pit();
    Pit(int);  //inherits age from animal
	int getrow();
	int getcolumn();
	int getoriginalr();
    int getoriginalc();
	void setrow(int);
	void setcolumn(int);
	void setoriginalr(int);
    void setoriginalc(int);
	void encounter();
	void percept();
	bool wake();

private:
    int away;
	int row;
	int column;
	int originalr;
	int originalc;
    
};
#endif
