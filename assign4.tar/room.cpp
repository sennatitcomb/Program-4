/*
	Room Class
*/
#include <iostream>
#include "room.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Room(string)
** Description: Alternate Room constructor
** Parameters: string measure
** Pre-conditions: string
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Room::Room(string measure) {
	//cout << "Alternate Room constructor called" << endl;
    srand(time(NULL));
    this->measurements = string_convert(measure);
    cave.resize(measurements);
    gamecave.resize(measurements);
    gameover = false;
    row = 0;
    column = 0;
    arrowcount = 0;
    collect = false;
    originalr = 0;
    originalc = 0;
    alive = true;
    Wumpus w;
    Bats b;
    Pit p;
    Gold g;
    Event *e1 = &w;
    Event *e2 = &b;
    Event *e3 = &p;
    Event *e4 = &g;
}

/*************************************************************************************************************************************
** Function: Room()
** Description: Default Room constructor
** Parameters: none
** Pre-conditions: none
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Room::Room() {
	//cout << "Default Room constructor called" << endl;
    srand(time(NULL));
    measurements = 0;
    cave.resize(measurements);
    gamecave.resize(measurements);
    gameover = false;
    row = 0;
    column = 0;
    arrowcount = 0;
    collect = false;
    originalr = 0;
    originalc = 0;
    alive = true;
    Wumpus w;
    Bats b;
    Pit p;
    Gold g;
    Event *e1 = &w;
    Event *e2 = &b;
    Event *e3 = &p;
    Event *e4 = &g;
}

/*************************************************************************************************************************************
** Function: ~Room()
** Description: Room destructor
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: destructs all variables
*************************************************************************************************************************************/
Room::~Room() {
   // cout << "Room Destructor" << endl;
}

/*************************************************************************************************************************************
** Function: ignore()
** Description: Cleans up cin
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: cin is cleared
*************************************************************************************************************************************/
void Room::ignore() {
    cin.clear();
    cin.ignore(1000, '\n');
}

/*************************************************************************************************************************************
** Function: getM()
** Description: Measurement accessor
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns measurements for cave
*************************************************************************************************************************************/
int Room::getM() {
    return measurements;
} 

/*************************************************************************************************************************************
** Function: setM(string)
** Description: Mutator for measurements
** Parameters: string measure
** Pre-conditions: string
** Post-conditions: sets measurements
*************************************************************************************************************************************/
void Room::setM(string measure) {
    this->measurements = string_convert(measure);
} 

/*************************************************************************************************************************************
** Function: playGame()
** Description: Lets User play game until death or win
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: creates game and plays
*************************************************************************************************************************************/
void Room::playGame() {
    makeboard();
    assignW1();
    assignB();
    assignB();
    assignP();
    assignP();
    assignG1();
    assignA();
    while (gameover == false) {
        checkEvent();
        checkNearby();
        Move();
        ignore();
        gameOver();
    }
}

/*************************************************************************************************************************************
** Function: gameOver()
** Description: Tests if User won game by collecting gold (and/or killing Wumpus) and returning to same room
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: Determines win 
*************************************************************************************************************************************/
void Room::gameOver() {
    if (collect == true && originalr == row && originalc == column) {
        cout << "You have won the game!" << endl;
        gameover = true;
        exit(0);
    } 
}

/*************************************************************************************************************************************
** Function: makeboard()
** Description: Sets the vectors cave and gamecave
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: creates and sets vectors
*************************************************************************************************************************************/
void Room::makeboard() {
    int Row = measurements;
    int Column = measurements;
    cave.resize(measurements);
    for (int i = 0; i < cave.size(); i++) { 
        cave[i].resize(measurements);
        for (int j = 0; j < cave[i].size(); j++) 
            cave[i][j] = ' '; 
    } 
    gamecave.resize(measurements);
    for (int i = 0; i < gamecave.size(); i++) { 
        gamecave[i].resize(measurements);
        for (int j = 0; j < gamecave[i].size(); j++) 
            gamecave[i][j] = ' '; 
    } 
}

/*************************************************************************************************************************************
** Function: assignA()
** Description: Sets the original adventurer position
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: original position is set
*************************************************************************************************************************************/
void Room::assignA() {
    row = rand()%measurements;
    column = rand()%measurements;
    originalr = row;
    originalc = column;
    if (cave[row][column] == ' '){
        cave[row][column] = 'E';
        placeUser(cave, row, column);
    } else {
        assignA();
    }
}

/*************************************************************************************************************************************
** Function: assignW1()
** Description: Sets the original wumpus position
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: original position is set
*************************************************************************************************************************************/
void Room::assignW1() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    e1->setoriginalr(x);
    e1->setoriginalc(y);
    if (cave[x][y] == ' '){
        cave[x][y] = 'W';
        e1->setrow(x);
        e1->setcolumn(y);
    } else {
        assignW1();
    }
}

/*************************************************************************************************************************************
** Function: assignW()
** Description: Sets the wumpus position
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignW() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    if (cave[x][y] == ' '){
        cave[x][y] = 'W';
        e1->setrow(x);
        e1->setcolumn(y);
    } else {
        assignW();
    }
}

/*************************************************************************************************************************************
** Function: assignB()
** Description: Sets the superbat positions
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignB() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    if (cave[x][y] == ' '){
        cave[x][y] = 'B';
        e2->setrow(x);
        e2->setcolumn(y);
    } else {
        assignB();
    }
}

/*************************************************************************************************************************************
** Function: assignP()
** Description: Sets the pit positions
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignP() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    if (cave[x][y] == ' '){
        cave[x][y] = 'P';
        e3->setrow(x);
        e3->setcolumn(y);
    } else {
        assignP();
    }
}

/*************************************************************************************************************************************
** Function: restart()
** Description: Lets user restart game with the same configuration, new ones, or quit
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: new game is created or program is quit
*************************************************************************************************************************************/
void Room::restart() {
    int choose;
    cout << "Would you like to restart the game, start a new one, or quit? Enter 1, 2, or 3." << endl;
    cin >> choose;
    if (choose == 1){
        reset();
        assignG2();
        assignW2();
        row = originalr;
        column = originalc;
        placeUser(cave, row, column);
    } else if (choose == 2) {
        reset();
        playGame();
    } else if (choose == 3) {
        exit(0);
    }
}

/*************************************************************************************************************************************
** Function: reset()
** Description: Variables are reset
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: variables are reset
*************************************************************************************************************************************/
void Room::reset() {
    ignore();
    collect = false;
    alive = true; 
    this->arrowcount = 0;
    gameover = false;
}

/*************************************************************************************************************************************
** Function: assignG()
** Description: Sets the gold position
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignG() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    if (cave[x][y] == ' '){
        cave[x][y] = 'G';
        e4->setrow(x);
        e4->setcolumn(y);
    } else {
        assignG();
    }
}

/*************************************************************************************************************************************
** Function: assignG1()
** Description: Sets the original gold position
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: original position is set
*************************************************************************************************************************************/
void Room::assignG1() {
    int x = rand()%measurements;
    int y = rand()%measurements;
    e4->setoriginalr(x);
    e4->setoriginalc(y);
    if (cave[x][y] == ' '){
        cave[x][y] = 'G';
        e4->setrow(x);
        e4->setcolumn(y);
    } else {
        assignG1();
    }
}

/*************************************************************************************************************************************
** Function: assignG2()
** Description: Sets the old position for gold in reset game
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignG2() {
    if (cave[e4->getoriginalr()][e4->getoriginalc()] == ' '){
        cave[e4->getoriginalr()][e4->getoriginalc()] = 'G';
    }
}
/*************************************************************************************************************************************
** Function: assignW2()
** Description: Sets the old position for wumpus in reset game
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: position is set
*************************************************************************************************************************************/
void Room::assignW2() {
    if (cave[e1->getoriginalr()][e1->getoriginalc()] == ' '){
        cave[e1->getoriginalr()][e1->getoriginalc()] = 'W';
    }
}

/*************************************************************************************************************************************
** Function: deleteW()
** Description: deletes wumpus
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: no more wumpus
*************************************************************************************************************************************/
void Room::deleteW() {
    int x = e1->getrow();
    int y = e1->getcolumn();
    cave[x][y] = ' ';
}

/*************************************************************************************************************************************
** Function: deleteG()
** Description: deletes gold when player collects
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: gold is collected
*************************************************************************************************************************************/
void Room::deleteG() {
    int x = e4->getrow();
    int y = e4->getcolumn();
    cave[x][y] = ' ';
}

/*************************************************************************************************************************************
** Function: checkEvent()
** Description: sees if user is in empty room or not
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: if not in empty, encounters event
*************************************************************************************************************************************/
void Room::checkEvent() {
    if(cave[row][column] == 'W') {
        e1->encounter();
        gameover = true;
        restart();
    } else if (cave[row][column] == 'B') {
        e2->encounter();
        row = rand()%measurements;
        column = rand()%measurements;
        placeUser(cave, row, column);
        checkEvent();
    }else if (cave[row][column] == 'P') {
        e3->encounter();
        gameover = true;
        restart();
    }else if (cave[row][column] == 'G'){
        e4->encounter();
        collect = true;
        deleteG();
    }
}

/*************************************************************************************************************************************
** Function: shootUp()
** Description: shoots the arrow north
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: can kill wumpus, wake, or do nothing
*************************************************************************************************************************************/
void Room::shootUp(){
    int shotr = row;
    int shotc = column;
    bool change = true;
    while(shotr>0) {
        shotr--;
        if(cave[shotr][shotc] == 'W') {
            cout << "You have killed the Wumpus!";
            deleteW();
            alive = false;
            break;
        }else if(cave[shotr][shotc] != 'W' && shotr==0 && alive == true) {
            change = w.wake();
            if(change == true) {
                deleteW();
                assignW();
            }
            break;
        }
    }
}

/*************************************************************************************************************************************
** Function: shootLeft()
** Description: shoots the arrow West
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: can kill wumpus, wake, or do nothing
*************************************************************************************************************************************/
void Room::shootLeft(){
    int shotr = row;
    int shotc = column;
    bool change = true;
    while(shotc>0) {
        shotc--;
        if(cave[shotr][shotc] == 'W') {
            cout << "You have killed the Wumpus!";
            deleteW();
            alive = false;
            break;
        }else if(cave[shotr][shotc] != 'W' && shotc==0 && alive == true) {
            change = w.wake();
            if(change == true) {
                deleteW();
                assignW();
            }
            break;
        }
    }
}

/*************************************************************************************************************************************
** Function: shootDown()
** Description: shoots the arrow east
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: can kill wumpus, wake, or do nothing
*************************************************************************************************************************************/
void Room::shootDown(){
    int shotr = row;
    int shotc = column;
    bool change = true;
    while(shotr<measurements-1) {
        shotr++;
        if(cave[shotr][shotc] == 'W') {
            cout << "You have killed the Wumpus!";
            deleteW();
            alive = false;
            break;
        }else if(cave[shotr][shotc] != 'W' && shotr==measurements-1 && alive == true) {
            change = w.wake();
            if(change == true) {
                deleteW();
                assignW();
            }
            break;
        }
    }
}

/*************************************************************************************************************************************
** Function: shootRight()
** Description: shoots the arrow east
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: can kill wumpus, wake, or do nothing
*************************************************************************************************************************************/
void Room::shootRight(){
    int shotr = row;
    int shotc = column;
    bool change = true;
    while(shotc<measurements-1) {
        shotc++;
        if(cave[shotr][shotc] == 'W') {
            cout << "You have killed the Wumpus!";
            deleteW();
            alive = false;
            break;
        }else if(cave[shotr][shotc] != 'W' && shotc==measurements-1 && alive == true) {
            change = w.wake();
            if(change == true) {
                deleteW();
                assignW();
            }
            break;
        }
    }
}

/*************************************************************************************************************************************
** Function: Arrow(char choice)
** Description: adventurer shoots an arrow 
** Parameters: char choice
** Pre-conditions: char
** Post-conditions: can kill wumpus, wake, or do nothing
*************************************************************************************************************************************/
void Room::Arrow(char choice){
    if (arrowcount<3) {
        if (choice == 'W') {
            arrowcount++;
            shootUp();
        }else if (choice == 'A') {
            arrowcount++;
            shootLeft();
        }else if (choice == 'S') {
            arrowcount++;
            shootDown();
        }else if (choice == 'D') {
            arrowcount++;
            shootRight();
        }else {
            cout << "That is not a valid direction." << endl;
            Move();
        }
    } else {
        cout << "You are out of arrows!" << endl;
        ignore();
        //Move();
    }
    ignore();
}

/*************************************************************************************************************************************
** Function: checkNearby()
** Description: checks for nearby events
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns percept
*************************************************************************************************************************************/
void Room::checkNearby() {
    checkAbove();
    checkBelow();
    checkLeft();
    checkRight();
}

/*************************************************************************************************************************************
** Function: checkAbove()
** Description: checks for above events
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns percept
*************************************************************************************************************************************/
void Room::checkAbove() {
    if((row-1)>=0) {
        if(cave[row-1][column] == 'W') {
            e1->percept();
        }else if(cave[row-1][column] == 'B') {
            e2->percept();
        }else if(cave[row-1][column] == 'P') {
            e3->percept();
        }else if(cave[row-1][column] == 'G') {
            e4->percept();
        }
    }
    
}
/*************************************************************************************************************************************
** Function: checkBelow()
** Description: checks for below events
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns percept
*************************************************************************************************************************************/
void Room::checkBelow() {
    if((row+1)<measurements) {
        if(cave[row+1][column] == 'W') {
            e1->percept();
        }else if(cave[row+1][column] == 'B') {
            e2->percept();
        }else if(cave[row+1][column] == 'P') {
            e3->percept();
        }else if(cave[row+1][column] == 'G') {
            e4->percept();
        }
    }
}

/*************************************************************************************************************************************
** Function: checkLeft()
** Description: checks for events to west
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns percept
*************************************************************************************************************************************/
void Room::checkLeft() {
    if((column-1)>=0) {
        if(cave[row][column-1] == 'W') {
            e1->percept();
        }else if(cave[row][column-1] == 'B') {
            e2->percept();
        }else if(cave[row][column-1] == 'P') {
            e3->percept();
        }else if(cave[row][column-1] == 'G') {
            e4->percept();
        }
    }
}

/*************************************************************************************************************************************
** Function: checkRight()
** Description: checks for events to east
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns percept
*************************************************************************************************************************************/
void Room::checkRight() {
    if((column+1)<measurements) {
        if(cave[row][column+1] == 'W') {
            e1->percept();
        }else if(cave[row][column+1] == 'B') {
            e2->percept();
        }else if(cave[row][column+1] == 'P') {
            e3->percept();
        }else if(cave[row][column+1] == 'G') {
            e4->percept();
        }
    }
}

/*************************************************************************************************************************************
** Function: game(string version)
** Description: checks which version to run
** Parameters: N/A
** Pre-conditions: N/A
** Post-conditions: returns debug or normal version
*************************************************************************************************************************************/
void Room::game(string version) {
    if (version == "True") {
        debug = true;
    } else {
        debug = false;
    }
}


/*************************************************************************************************************************************
** Function: string_convert()
** Description: Converts the string to an integer
** Parameters: string number
** Pre-conditions: take a string number
** Post-conditions: return the integer
*************************************************************************************************************************************/
int Room::string_convert(string number) {
    int newNumber = 0;

    for (int x = 0; x < number.length(); x++)
        newNumber += ((int) number[x] - 48) * pow(10, (number.length() - 1 - x));

    return newNumber;
}

/*************************************************************************************************************************************
** Function: printCave(vector<vector<char> > gamecave, int Row, int Column)
** Description: Takes in Row and Column to print out the cave
** Parameters: vector<vector<char> > gamecave, int Row, int Column
** Pre-conditions: take in vector<vector<char> > gamecave, int Row, int Column
** Post-conditions: prints out the cave
*************************************************************************************************************************************/
void Room::printCave(vector<vector<char> > cave, int Row, int Column) {
    /*for(int i=0; i<Column; i ++){
        //this code is for the number spacing
	    if(i <= 9) cout << "  " << i << " ";
    	    else cout << " " << i << " ";
    }*/
    cout << "\n";
    for (int i=0; i<Row; i++) {
            for (int j=0; j<Column; j++) {
                //This code creates the shading and spacing of the cave
                if (i % 2 == 0 && j % 2 == 0) {
                    cout << "|\033[30;47m " << cave[i][j] << " " << "\033[0m";
                }else if (i % 2 == 1 && j % 2 == 1) {
                    cout << "|\033[30;47m " << cave[i][j] << " " << "\033[0m";
                }else {
                    cout << "|\033[0m " << cave[i][j] << " ";
                }
                
            }
        cout <<"|\033[0m " << "\n";
    }
}

/*************************************************************************************************************************************
** Function: printGame(vector<vector<char> > gamecave, int Row, int Column)
** Description: Takes in Row and Column to print out the gamecave
** Parameters: vector<vector<char> > gamecave, int Row, int Column
** Pre-conditions: take in vector<vector<char> > gamecave, int Row, int Column
** Post-conditions: prints out the gamecave
*************************************************************************************************************************************/
void Room::printGame(vector<vector<char> > gamecave, int Row, int Column) {
    cout << "\n";
    for (int i=0; i<Row; i++) {
            for (int j=0; j<Column; j++) {
                //This code creates the shading and spacing of the cave
                if (i % 2 == 0 && j % 2 == 0) {
                    cout << "|\033[30;47m " << gamecave[i][j] << " " << "\033[0m";
                }else if (i % 2 == 1 && j % 2 == 1) {
                    cout << "|\033[30;47m " << gamecave[i][j] << " " << "\033[0m";
                }else {
                    cout << "|\033[0m " << gamecave[i][j] << " ";
                }
                
            }
        cout <<"|\033[0m " << "\n";
    }
}

/*************************************************************************************************************************************
** Function: Move()
** Description: Lets User move to new room
** Parameters: None
** Pre-conditions: None
** Post-conditions: moves *
*************************************************************************************************************************************/
void Room::Move() {
    char choice = ' ';
    char achoice = ' ';
    cout << "Enter W to go North, A to go West, S to go South, D to go East, or Space and a Direction to shoot an arrow." << endl;
    cin >> noskipws >> choice;
    if (choice == 'W') {
        row--;
        placeUser(cave, row, column);
    }else if (choice == 'A') {
        column--;
        placeUser(cave, row, column);
    }else if (choice == 'S') {
        row++;
        placeUser(cave, row, column); 
    }else if (choice == 'D') {
        column++;
        placeUser(cave, row, column);
    }else if (choice == ' ') {
        cin >> achoice;
        Arrow(achoice);
    }else {
        cout << "That was not a valid move." << endl;
        //ignore();
        Move();
    }
    ignore();
}


/*************************************************************************************************************************************
** Function: placeUser()
** Description: Place * on cave
** Parameters: char** cave, int Row, int Column
** Pre-conditions: take in char** cave, int Row, int Column
** Post-conditions: prints updated cave
*************************************************************************************************************************************/
void Room::placeUser(vector<vector<char> > cave, int Row, int Column) {
    //This code allows the user to place adventurer in new Room
    bool open = false;

    if (Row < measurements && Row >= 0 && Column < measurements && Column >= 0) {
        open = true;
    }

    if (open) {
        cave[Row][Column] = '*';
        gamecave[Row][Column] = '*';
        if (debug == true) {
            printCave(cave, measurements, measurements);
        } else {
            printGame(gamecave, measurements, measurements);
        }
        cave[Row][Column] = ' ';
        gamecave[Row][Column] = ' ';
    } else {
        cout << "You cannot move there. The Cave has ended." << endl;
        Move();
    } 
    
}