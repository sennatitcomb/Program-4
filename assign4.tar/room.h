/*
	Room Class
*/
#ifndef ROOM_H
#define ROOM_H

#include <iostream>
#include <fstream>
#include <ncurses.h>
#include <vector>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include "event.h"
#include "wumpus.h"
#include "bats.h"
#include "pit.h"
#include "gold.h"
using namespace std;

class Room {
public:
	Room();
	Room(string);
    ~Room();
    void ignore();
    int string_convert(string);
    int getM();
    void setM(string);
    void game(string);
    void playGame();
    void placeUser(vector<vector<char> >, int, int);
    void Move();
    void assignA();
    void assignW();
    void assignB();
    void assignP();
    void assignG();
    void assignG1();
    void assignG2();
    void assignW1();
    void assignW2();
    void makeboard();
    void printCave(vector<vector<char> >, int, int);
    void printGame(vector<vector<char> >, int, int);
    void checkEvent();
    void checkNearby();
    void checkAbove();
    void checkBelow();
    void checkLeft();
    void checkRight();
    void Arrow(char);
    void deleteW();
    void deleteG();
    void shootUp();
    void shootLeft();
    void shootDown();
    void shootRight();
    void gameOver();
    void restart();
    void reset();

private:
    int measurements;
    vector<vector<char> > cave; 
    vector<vector<char> > gamecave; 
    int row;
    int column;
    int originalr;
    int originalc;
    bool alive;
    bool inRoom;
    int arrowcount;
    bool collect;
    bool gameover;
    bool debug;
    Wumpus w;
    Bats b;
    Pit p;
    Gold g;
    Event *e1 = &w;
    Event *e2 = &b;
    Event *e3 = &p;
    Event *e4 = &g;

};
#endif