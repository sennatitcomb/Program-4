/*
	Wumpus Class
*/
#include <iostream>
#include "wumpus.h"

using namespace std;

/*************************************************************************************************************************************
** Function: Wumpus() : Event()
** Description: Default Wumpus constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Wumpus::Wumpus() : Event(){
  //  cout << "Default Wumpus constructor called" << endl;
    away = 0;
    row = 0;
    originalr = 0;
    originalc = 0;
    column = 0;

}

/*************************************************************************************************************************************
** Function: Wumpus(int Away) : Event(Away)
** Description: Alternate Wumpus constructor called, derives from Event
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: constructs all variables
*************************************************************************************************************************************/
Wumpus::Wumpus(int Away) : Event(Away){
  //  cout << "Alternate Wumpus constructor called" << endl;
    this->away = Away;
    row = 0;
    originalr = 0;
    originalc = 0;
    column = 0;
}

/*************************************************************************************************************************************
** Function: getoriginalr()
** Description: Accessor for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original row
*************************************************************************************************************************************/
int Wumpus::getoriginalr() {
    return originalr;
}

/*************************************************************************************************************************************
** Function: getoriginalc()
** Description: Accessor for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns original column
*************************************************************************************************************************************/
int Wumpus::getoriginalc(){
    return originalc;
}

/*************************************************************************************************************************************
** Function: getrow()
** Description: Accessor for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current row
*************************************************************************************************************************************/
int Wumpus::getrow() {
    return row;
}

/*************************************************************************************************************************************
** Function: getcolumn()
** Description: Accessor for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: returns current column
*************************************************************************************************************************************/
int Wumpus::getcolumn(){
    return column;
}

/*************************************************************************************************************************************
** Function: setrow()
** Description: Mutator for current row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current row
*************************************************************************************************************************************/
void Wumpus::setrow(int Row) {
    this->row = Row;
}

/*************************************************************************************************************************************
** Function: setcolumn()
** Description: Mutator for current column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets current column
*************************************************************************************************************************************/
void Wumpus::setcolumn(int Column){
    this->column = Column;
}

/*************************************************************************************************************************************
** Function: setoriginalr()
** Description: Mutator for original row
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original row
*************************************************************************************************************************************/
void Wumpus::setoriginalr(int Originalr) {
    this->originalr = Originalr;
}

/*************************************************************************************************************************************
** Function: setoriginalc()
** Description: Mutator for original column
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: sets original column
*************************************************************************************************************************************/
void Wumpus::setoriginalc(int Originalc){
    this->originalc = Originalc;
}

/*************************************************************************************************************************************
** Function: encounter()
** Description: Sends message for encounter
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Wumpus::encounter() {
    cout << "You have entered the Wumpus room and been eaten." << endl;
}

/*************************************************************************************************************************************
** Function: percept()
** Description: Sends message for nearby
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message
*************************************************************************************************************************************/
void Wumpus::percept() {
    cout << "You smell a terrible stench." << endl;
}

/*************************************************************************************************************************************
** Function: wake()
** Description: Calculates if wake or not, sends message
** Parameters: n/a
** Pre-conditions: n/a
** Post-conditions: couts message and returns true or false
*************************************************************************************************************************************/
bool Wumpus::wake() {
    int x = rand()%100+1;
    if (x >= 25) {
        cout << "The Wumpus woke up and moved to a new room!";
        return true;
    } else {
        cout << "The arrow did not wake the Wumpus";
        return false;
    }
    return true;
}
