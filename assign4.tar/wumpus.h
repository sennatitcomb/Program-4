/*
	Wumpus Class
*/
#ifndef WUMPUS_H
#define WUMPUS_H

#include <iostream>
#include "event.h"

using namespace std;

class Wumpus : public Event {
public:
	Wumpus();
    Wumpus(int);  //inherits age from animal
	int getrow();
	int getcolumn();
	int getoriginalr();
    int getoriginalc();
	void setrow(int);
	void setcolumn(int);
	void setoriginalr(int);
    void setoriginalc(int);
	void encounter();
	void percept();
	bool wake();

private:
    int away;
	int row;
	int column;
	int originalr;
	int originalc;
    
};
#endif
