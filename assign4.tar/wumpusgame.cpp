/******************************************************
** Program: wumpusgame.cpp
** Author: Senna Titcomb
** Date: 05/24/2020
** Description: A game program where a user (adventurer) enters a cave with a determined amount of rooms and must collect the gold and/or kill the Wumbus to win.
** Each room has 4 tunnels that the user may travel through and each room will either be empty or have one random event. 
** The user will start in a random room and should be able to get back to the room to escape.
** Input: the rooms in the cave (it is a square so the rows given across will suffice), 
** true or false to let the program know whether to run debug mode or game mode, the keys W, A, S, D which are used to move,
** the choice to either restart the game with the same or random configuration or quit the game, and the choice to fire an arrow in a direction
** Output: the board, the messages about the rooms and game (which includes when the adventurer is nearby or in the room as well as what happens when the adventurer shoots an arrow), 
** as well as the result of the game
******************************************************/

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <exception>
#include "room.h"
#include "event.h"
#include "wumpus.h"
//#include "bats.h"
//#include "pit.h"
//#include "gold.h"


using namespace std;

int main(int argc, char* argv[]) {
    if (argc == 3) {  //This is checking the number of arguments entered
        cout << "Welcome to Hunt the Wumpus!" << endl;
        Room r1;
        string Measure = argv[1];
        int newNumber = 0;
        for (int x = 0; x < Measure.length(); x++) {
            newNumber += ((int) Measure[x] - 48) * pow(10, (Measure.length() - 1 - x));
        }
        if ((newNumber < 4) || ((strcmp(argv[2], "True") != 0) && (strcmp(argv[2], "False") != 0))) {
            cout << "Your cave measurements must be 4 or more and True for the debug version or False for the normal." << endl;
        } else {
            string Version = argv[2];
            r1.setM(Measure);
            r1.game(Version);
            r1.playGame();
        }
    } else {
        cout <<"You did not enter the correct number of arguements."<<endl;
    }
	return 0;
}